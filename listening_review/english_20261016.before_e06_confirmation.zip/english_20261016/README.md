# 英文试听（修正链接版）

本目录为原始音频的逐字节副本，使用相对链接，可整体移动；没有重新合成或改变音频。

先听 E06，确认正文结束后是否出现额外语音；再核验 E01～E05。所有英文样本仍待人工核验。

## E01 · Mia（7.04 秒）

Morning sunlight fell across the quiet desk. She opened the old book and began to read.

[试听 E01](E01_Mia.wav)

## E02 · Mia（7.04 秒）

Do you remember where we agreed to meet? Please wait beside the bridge until I arrive.

[试听 E02](E02_Mia.wav)

## E03 · Chloe（7.36 秒）

Morning sunlight fell across the quiet desk. She opened the old book and began to read.

[试听 E03](E03_Chloe.wav)

## E04 · Chloe（6.88 秒）

Do you remember where we agreed to meet? Please wait beside the bridge until I arrive.

[试听 E04](E04_Chloe.wav)

## E05 · Milo（6.56 秒）

Morning sunlight fell across the quiet desk. She opened the old book and began to read.

[试听 E05](E05_Milo.wav)

## E06 · Milo（14.56 秒）

Do you remember where we agreed to meet? Please wait beside the bridge until I arrive.

[试听 E06](E06_Milo.wav)

## 两章完整音频

[普通旁白](chapter_01_en.mp3) · [双角色](chapter_02_en.mp3)

如果 Markdown 预览不支持播放，可直接打开同目录 index.html，用浏览器试听。
