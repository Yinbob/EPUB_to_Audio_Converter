# 英文试听（修正链接版）

本目录为原始音频的逐字节副本，使用相对链接，可整体移动；没有重新合成或改变音频。

人工核验已完成：E01～E05 正常；E06 后半段额外朗读，内容不合格。保留原始问题样本供定位，尚未重新合成。

## E01 · Mia（7.04 秒）

Morning sunlight fell across the quiet desk. She opened the old book and began to read.

[试听 E01](E01_Mia.wav)

## E02 · Mia（7.04 秒）

Do you remember where we agreed to meet? Please wait beside the bridge until I arrive.

[试听 E02](E02_Mia.wav)

## E03 · Chloe（7.36 秒）

Morning sunlight fell across the quiet desk. She opened the old book and began to read.

[试听 E03](E03_Chloe.wav)

## E04 · Chloe（6.88 秒）

Do you remember where we agreed to meet? Please wait beside the bridge until I arrive.

[试听 E04](E04_Chloe.wav)

## E05 · Milo（6.56 秒）

Morning sunlight fell across the quiet desk. She opened the old book and began to read.

[试听 E05](E05_Milo.wav)

## E06 · Milo（14.56 秒）

Do you remember where we agreed to meet? Please wait beside the bridge until I arrive.

[试听 E06](E06_Milo.wav)

## 两章完整音频

[普通旁白](chapter_01_en.mp3) · [双角色](chapter_02_en.mp3)

如果 Markdown 预览不支持播放，可直接打开同目录 index.html，用浏览器试听。

E06 的原始单次 MiMo 返回已包含额外内容；试听副本与原始文件哈希一致。两章中的双角色版本也包含该问题。请勿将 E06 或双角色整章当作合格音频。
